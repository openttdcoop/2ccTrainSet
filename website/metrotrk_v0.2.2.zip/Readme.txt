Metro Track Set
===============
The Metro Track Set is designed to complement the metros of the 2cc Set.



License
=======
Use of the Metro Track Set is licensed under the Creative Commons Attribution-Noncommercial-No Derivative Works 3.0 Unported license (http://creativecommons.org/licenses/by-nc-nd/3.0/). This means that you may use this set in your TTDPatch and OpenTTD games and may distribute this set provided that you credit the authors (see below) properly. You may not sell (parts of) this set and may not reuse (parts of) this set for instance in your own set.



Background information
======================
The system used in this set is commonly known as a 'bottom contact third rail', where the third rail sits at either side of the running rails and is slightly elevated above the ground (in the order of a foot (30 cm) or something). This type of third rail has a protective cover on top of the live rail preventing direct contact and therefore limiting the risk of electrocution.
This set is inspired by the Dutch metro systems of Amsterdam and Rotterdam which both use the type of third rail as described above (and where the protective cover is in fact yellow).




Dos or Windows version? It Is Not About Your Operating System!
==============================================================
Whether you need the dos version (metrotrk.grf) or the windows version (MetroTrackSetW.grf) of this set depends on the version of the original graphics you are using. For TTDPatch, there are located in the TTD root directory. For OpenTTD, you can find these in the data folder in the directory where you installed OpenTTD. Now check the file names of the original graphics: trg1.grf indicates the dos version, while trg1r.grf indicates the windows version (note the extra "r"!).




Third Party Set Support
=======================
The Metro Track Set has native support for the OpenGFX replacement sets, the Total Town Replacement Set, the North American Roads Set and the UK Roadset. These sets are detected automatically by GRF-ID. In future versions of these sets GRF-IDs may change (bound to happen to the OpenGFX sets). Any change in GRF-ID will break auto-detection. In case this happens, you can re-enable third party set support by setting a parameter value. This parameter value is a bit mask. For your convenience, you may set parameter value 1 to enable full OpenGFX support.

Other set support is controlled by the aforementioned bitmask. This feature is provided because you might want to use OpenGFX Infrastucture and GUI, TTRS roads but not OpenGFX bridges (because the current version (0.1) is still glitchy and therefore OpenGFX Metro Track bridges are also glitchy).
Just add the values (not the bits!) of the set support you wish to enable from the table below:

-----------------------------------------------------------------
|Bit|Value|Description                              |GRF-ID
-----------------------------------------------------------------
| 0 |   1 | Full OpenGFX support                    | n/a
| 1 |   2 | OpenGFX Infrastructure support          | 52 57 13 03
| 2 |   4 | OpenGFX Bridges support                 | 52 57 13 1F
| 3 |   8 | OpenGFX GUI support                     | 4D 41 30 34
| 4 |  16 | Total Town Replacement Set (v3) support | 56 43 00 01
| 5 |  32 | North American Roads Set (v1) support   | 43 41 52 61
| 6 |  64 | UK Roadset (v1) support                 | 55 4B 52 01
-----------------------------------------------------------------

Example:
In order to enable OpenGFX Infrastucture and GUI and TTRS support, set the parameter value to 26 (i.e. 2+8+16=26).

Please note that not all combinations are supported, for instance you can't have multiple road sets active at the same time (well, you can but only the graphics of the last loaded set are shown). Manual support override is subject to the order of the list above, e.g. if you set parameter value 96, you end up with UK Roads support and not NA Roads support.
This limitation also applies to the automatic detection feature.




Credits
=======
The metro tracks are drawn by Purno and the set was originally coded by XeryusTC. Development of the set was continued by DJ Nekkid but soon taken over by FooBar who recoded the set, added OpenGFX support and enhanced a thing or two, most notably the behaviour of the third rail at junctions.

The set contains (parts of) graphics by others:
TTD Graphics:                Simon Foster.
OpenGFX Tracks:              Zepyris (Richard Wheeler).
OpenGFX Bridges:             Zimmlock, Thgergo, Purno and Zephyris.
OpenGFX GUI:                 Bubersson and LordAzamath and Zephyris.
Total Town Replacement Set:  Csaboka, George, the Tycoonez.com:munity, Oz, Red*Star, Purno, Pikkabird and Zimmlock.
North American Roads Set:    Norfolksouthern37, Oracle, Lifeblood, Oz, OzTransLtd and Skidd13.
UK Roadset:                  Born Acorn.





Changelog
=========
v0.2.2
- Bugfix release.

v0.2.1
- Added support for TTRS, NARoads and UK Roadset.
- Added checks for grf order.
- Removed duplicate sprites.

v0.2
- Added OpenGFX support.
- Added level crossings.
- Added GUI elements.
- Redeveloped third rail behavior at junctions.
- Total recode of all elements in the set.

v0.1
- Initial release coded by XeryusTC.